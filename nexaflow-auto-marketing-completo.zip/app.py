import os, sqlite3, secrets, json
from datetime import datetime
from functools import wraps
from flask import Flask, request, jsonify, render_template, redirect, url_for, session
import mercadopago

BASE = os.path.dirname(os.path.abspath(__file__))
DB = os.path.join(BASE, "nexaflow.db")

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY") or secrets.token_hex(32)

ADMIN_USER = os.environ.get("ADMIN_USER", "admin")
ADMIN_PASSWORD = os.environ.get("ADMIN_PASSWORD", "")
PRODUCT_NAME = os.environ.get("PRODUCT_NAME", "Nexa Start")
PRODUCT_PRICE = float(os.environ.get("PRODUCT_PRICE", "197"))
PRODUCT_DESCRIPTION = os.environ.get("PRODUCT_DESCRIPTION", "Produto digital NexaFlow.")
DELIVERY_URL = os.environ.get("PRODUCT_DELIVERY_URL", "")
SITE_URL = os.environ.get("SITE_URL", "")

def db():
    c = sqlite3.connect(DB)
    c.row_factory = sqlite3.Row
    return c

def init_db():
    c = db()
    c.executescript("""
    CREATE TABLE IF NOT EXISTS orders(
      id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,email TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'pending',mp_payment_id TEXT UNIQUE,
      mp_status TEXT,amount REAL NOT NULL,created_at TEXT NOT NULL,updated_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS events(
      id INTEGER PRIMARY KEY AUTOINCREMENT,kind TEXT,payload TEXT,created_at TEXT);
    CREATE TABLE IF NOT EXISTS campaigns(
      id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT,channel TEXT,content TEXT,
      status TEXT DEFAULT 'draft',created_at TEXT NOT NULL);
    """)
    c.commit(); c.close()

def log(kind, payload):
    c=db()
    c.execute("INSERT INTO events(kind,payload,created_at) VALUES(?,?,?)",
              (kind,json.dumps(payload,ensure_ascii=False),datetime.utcnow().isoformat()))
    c.commit(); c.close()

def auth(f):
    @wraps(f)
    def w(*a,**k):
        if not session.get("admin"): return redirect(url_for("login"))
        return f(*a,**k)
    return w

@app.get("/")
def home():
    return render_template("home.html", name=PRODUCT_NAME, price=PRODUCT_PRICE, description=PRODUCT_DESCRIPTION)

@app.post("/api/checkout")
def checkout():
    d=request.get_json(silent=True) or {}
    name=(d.get("name") or "").strip()
    email=(d.get("email") or "").strip()
    token=os.environ.get("MERCADOPAGO_ACCESS_TOKEN")
    if not name or not email: return jsonify(error="Nome e e-mail são obrigatórios."),400
    if not token: return jsonify(error="Mercado Pago não configurado."),500

    now=datetime.utcnow().isoformat()
    c=db()
    cur=c.execute("INSERT INTO orders(name,email,amount,created_at,updated_at) VALUES(?,?,?,?,?)",
                  (name,email,PRODUCT_PRICE,now,now))
    oid=cur.lastrowid; c.commit(); c.close()

    try:
        sdk=mercadopago.SDK(token)
        base=(SITE_URL or request.host_url).rstrip("/")
        pref={
          "items":[{"title":PRODUCT_NAME,"description":PRODUCT_DESCRIPTION,
                    "quantity":1,"unit_price":PRODUCT_PRICE,"currency_id":"BRL"}],
          "payer":{"name":name,"email":email},
          "external_reference":str(oid),
          "back_urls":{"success":base+"/payment/success","failure":base+"/payment/failure","pending":base+"/payment/pending"},
          "auto_return":"approved",
          "notification_url":base+"/webhooks/mercadopago"
        }
        r=sdk.preference().create(pref)
        if r.get("status") not in (200,201): return jsonify(error="Falha ao criar checkout."),502
        log("checkout_created",{"order_id":oid})
        return jsonify(ok=True,checkout_url=r["response"].get("init_point"),order_id=oid)
    except Exception as e:
        log("checkout_exception",{"order_id":oid,"error":repr(e)})
        return jsonify(error="Erro ao criar pagamento."),500

def sync_payment(payment_id):
    token=os.environ.get("MERCADOPAGO_ACCESS_TOKEN")
    if not token: return
    r=mercadopago.SDK(token).payment().get(payment_id)
    if r.get("status") != 200: return
    p=r["response"]; oid=p.get("external_reference")
    if not oid: return
    mp=p.get("status")
    st={"approved":"paid","pending":"pending","in_process":"pending",
        "rejected":"failed","cancelled":"failed","refunded":"refunded"}.get(mp,"pending")
    c=db()
    c.execute("UPDATE orders SET status=?,mp_payment_id=?,mp_status=?,updated_at=? WHERE id=?",
              (st,str(payment_id),mp,datetime.utcnow().isoformat(),int(oid)))
    c.commit(); c.close()
    log("payment_updated",{"order_id":oid,"payment_id":payment_id,"status":st})

@app.post("/webhooks/mercadopago")
def webhook():
    p=request.get_json(silent=True) or {}
    log("mercadopago_webhook",p)
    pid=request.args.get("data.id") or request.args.get("id")
    if not pid and isinstance(p.get("data"),dict): pid=p["data"].get("id")
    if pid:
        try: sync_payment(pid)
        except Exception as e: log("webhook_exception",repr(e))
    return jsonify(received=True)

@app.get("/payment/<state>")
def payment(state):
    m={"success":"Pagamento enviado para confirmação.","pending":"Pagamento pendente; a confirmação é automática.",
       "failure":"O pagamento não foi aprovado."}
    return render_template("payment.html",message=m.get(state,"Status do pagamento."))

@app.get("/api/marketing")
def marketing():
    # Public endpoint only returns generic, non-personalized promotional copy.
    return jsonify({
      "headline": f"{PRODUCT_NAME}: automatize sua operação",
      "text": f"{PRODUCT_DESCRIPTION} Conheça a oferta por R$ {PRODUCT_PRICE:.2f}.",
      "cta": "Conheça agora"
    })

@app.route("/login",methods=["GET","POST"])
def login():
    if request.method=="POST" and request.form.get("user")==ADMIN_USER and ADMIN_PASSWORD and request.form.get("password")==ADMIN_PASSWORD:
        session["admin"]=True; return redirect("/dashboard")
    return render_template("login.html")

@app.get("/logout")
def logout(): session.clear(); return redirect("/")

@app.get("/dashboard")
@auth
def dashboard():
    c=db()
    orders=c.execute("SELECT * FROM orders ORDER BY id DESC LIMIT 100").fetchall()
    campaigns=c.execute("SELECT * FROM campaigns ORDER BY id DESC LIMIT 50").fetchall()
    events=c.execute("SELECT * FROM events ORDER BY id DESC LIMIT 50").fetchall()
    c.close()
    return render_template("dashboard.html",orders=orders,campaigns=campaigns,events=events)

@app.post("/api/campaigns")
@auth
def campaign():
    d=request.get_json(silent=True) or {}
    title=(d.get("title") or "").strip()
    channel=(d.get("channel") or "draft").strip()
    content=(d.get("content") or "").strip()
    if not title or not content: return jsonify(error="Título e conteúdo são obrigatórios."),400
    c=db(); cur=c.execute("INSERT INTO campaigns(title,channel,content,created_at) VALUES(?,?,?,?)",
                           (title,channel,content,datetime.utcnow().isoformat()))
    c.commit(); c.close()
    return jsonify(ok=True,id=cur.lastrowid)

@app.get("/health")
def health(): return jsonify(status="ok",service="NexaFlow Auto Marketing")

init_db()
if __name__=="__main__":
    app.run(host="0.0.0.0",port=int(os.environ.get("PORT","5000")))
