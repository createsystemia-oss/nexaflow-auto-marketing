# Marketing automático — NexaFlow Auto

O projeto prepara o núcleo de vendas e possui endpoint `/api/marketing` para fornecer copy promocional genérica.

Para publicação automática em redes sociais, devem ser usadas APIs oficiais e as permissões/credenciais da própria conta. O projeto deliberadamente não envia spam, não cria contas falsas e não contorna limites das plataformas.

Para obter vendas, ainda é necessário tráfego. O sistema automatiza o funil depois que pessoas chegam à página; não existe garantia de vendas sem audiência.
